#########################################################################

           _                                             \_
         /   \____          ___________________      ____/  0   \___/
 ((((( __ / \_____   \ _ / ______SideWinder_ _ \ _ / ___________/   \ 
                   \ ____ /                   \ __ /
                                  2.2
########################################################################

Install/ Use

1. Extract archive to a folder of its own, usually sidewinder is fine


2. On linux all you have to do is type "./sidewinder.py", with windows you need python installed, if you dont it wont work at all.

Same method as linux once installed, except youll just be typing "sidewinder.py"



